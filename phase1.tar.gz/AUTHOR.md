# Autori

Alex Rossi alex.rossi7@studio.unibo.it 0001089916
Diego Barbieri diego.barbieri5@studio.unibo.it 0001080333
Giuseppe Iannone giuseppe.iannone2@studio.unibo.it 0001070486
Massimiliano Vittorio Incerti vittorio.incerti@studio.unibo.it 0001070634

