# SussySO
##### Diego Barbieri, Alex Rossi, Giuseppe Iannone, Vittorio Massimiliano Incerti
## Installazione
- Clonare la seguente directory -> git clone [url]
- seguire i passi in TUTORIAL.md
> _Nota_ <br>
> Non servirà scaricare lo starter-kit (è già presente in questa directory) dal portale del prof
